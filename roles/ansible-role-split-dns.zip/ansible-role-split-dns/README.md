Vars:
dnsmasq_local_dns - Address of local DNS server
dnsmasq_local_zone - Local network domain zone
dnsmasq_local_ip - PTR record for LAN IP pool (default 168.192.in-addr.arpa)
dnsmasq_resolver - List of upstream resolvers

Default:
dnsmasq_resolver:
  - 130.225.244.166
  - 185.38.24.52
  - 89.233.43.71
